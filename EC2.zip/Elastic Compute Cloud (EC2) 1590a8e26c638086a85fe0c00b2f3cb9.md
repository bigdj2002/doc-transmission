# Elastic Compute Cloud (EC2)

- EC2:
    - 안전하고 크기 조정이 가능한 컴퓨팅 파워를 클라우드에서 제공하는 웹 서비스
    - 개발자가 더 쉽게 웹 규모의 클라우드 컴퓨팅 작업을 할 수 있도록 설계됨
- EC2 보안 그룹:
    
    ![image.png](image.png)
    
    - 인스턴스에 대한 인바운드 및 아웃바운드 트래픽을 제어하는 가상 방화벽 역할
    - Port 허용:
        - 기본적으로 모든 포트는 비활성화
        - 선택적으로 트래픽이 지나갈 수 있는 Port와 Source를 설정 가능
        - Deny는 불가능
    - 인스턴스 단위:
        - 하나의 인스턴스에 하나 이상의 보안 그룹 설정 가능
        - 인스턴스에 여러 보안 그룹이 적용될 경우, 모든 보안 그룹의 규칙을 적용 받음
- EC2 구조:
    
    ![image.png](image%201.png)
    
    - EC2 인스턴스: EC2에서 컴퓨팅을 담당하고, 하나의 가용영역(Availability Zone, AZ)에 존재함
        - 인스턴스 유형
            
            ![image.png](image%202.png)
            
            - 인스턴스의 역할에 따라 CPU, 메모리, 스토리지, 네트워크 등을 조합한 구성
            - 각 인스턴스 유형 별로 사용 목적에 따라 최적화
                - ex) 메모리 위주, CPU 위주, GPU 위주 등등
            - 유형 별로 이름 존재
                - ex) t유형, m유형, inf유형 등
                - 같은 유형의 인스턴스들을 인스턴스 패밀리라고 부름
            - 타입 별 세대별로 숫자 부여
                - ex) m5: m인스턴스의 5번째 세대
            - 아키텍쳐 및 프로세서/추가기술에 따라 접미사
                - c7gn: c인스턴스 중, AWS Graviton 프로세서를 사용(g) + Network Optimization(n)
        - 인스턴스 크기
            - 인스턴스의 cpu 개수, 메모리 크기, 성능 등으로 크기를 결정
                
                ![image.png](image%203.png)
                
        - 인스턴스 유형 읽는 방법:
            
            ![image.png](image%204.png)
            
        - 저장을 담당하는 EBS와 네트워크로 연결
- EC2 저장소:
    - Elastic Block Sotre (EBS):
        - 가상 하드 드라이브
        - EC2 인스턴스가 종료되어도 계속 유지 가능
            - 루트 볼륨으로 사용시, EC2가 종료되면 같이 삭제됨
            - 단 설정을 통해서 EBS만 따로 존속 가능함
        - 용량을 범위에 따라 자유롭게 설정 가능
        - 특수하게 하나의 EBS를 여러 EC2 장착 가능한 경우도 있음 (EBS Multi Attach)
            
            ![image.png](image%205.png)
            
        - EC2 인스턴스와 같은 AZ에 존재함 (즉, 하나의 AZ 안에서만 존재함)
        - AZ안에 자동으로 분산 저장됨
            
            ![image.png](image%206.png)
            
    - EBS 유형:
        
        ![image.png](image%207.png)
        
        - 범용, 프로비전된 IOPS는 SSD 타입으로, 그 외는 HDD 타입으로 제공됨
    - Snapshot:
        - EBS의 특정 시점을 저장한 이미지
            - 이후, EBS로 다시 복구 가능
            - EBS의 백업 용도로 활용 가능
        - 증분식: 바뀐 부분에 대해서만 저장
        - S3에 저장됨
        - Data Lifecycle Manager / AWS Backup 등으로 자동화해서 생성 가능
        - 기타 여러 기능:
            - 암호화
            - 아카이브: 더 적은 비용으로 저장할 수 있으나, 몇가지 제약 사항 적용
                - 최소 90일 이상 저장
                - 복원에 최대 72시간 소요
            - 공유: 다른 계정등에 공유 가능
            - EBS Direct API를 활용해서 snapshot에 직접 내용을 쓰거나 읽기 가능
- EC2 템플릿:
    - Amazon Machine Image (AMI)
        - EC2 인스턴스를 실행하기 위해 필요한 정보를 모은 템플릿
        - 구성:
            - 1개 이상의 EBS snapshot
            - 사용 권한 (어떤 AWS account가 사용 가능한지)
            - 블록 디바이스 매핑 (EC2 인스턴스를 위한 볼륨 정보 = EBS가 어떤 용량으로 몇개나 붙는지)
        - 필요에 따라 Private으로 가지고 있거나, Public 공개 가능
    - 인스턴스 저장 유형에 따른 AMI 생성방법:
        - EBS: snapshot 기반으로 루트 디바이스 생성
        - 인스턴스 저장: S3에 저장된 템플릿을 기반으로 생성
        
        ![image.png](image%208.png)
        
        ![image.png](image%209.png)
        
    - AMI 구조:
        
        ![image.png](image%2010.png)
        
- EC2 생명주기:
    
    ![image.png](image%2011.png)
    
    - 중지:
        - 중지 중에는 인스턴스 요금 미청구
        - 단, EBS 요금, 다른 구성요소 (Elastic IP등)은 청구
        - 중지 후, 재시작시 public IP 변경
        - EBS를 사용하는 인스턴스만 중지 가능
    - 재부팅:
        - 재부팅시에는 public IP 변동 없음
    - 최대 절전모드:
        - 메모리 내용을 보존해서 재시작시 중단지점에서 시작할 수 있는 정지모드
    - 생명 주기별 요금
        
        ![image.png](image%2012.png)
        
- EC2 랜카드:
    - Elastic Network Interface (ENI):
        - ENI는 VPS에서 가상 네트워크 카드를 나타내는 논리적인 네트워킹 구성 요소
        - EC2의 가상의 랜카드
        - IP주소와 Mac 주소를 보유
        - 하나의 인스턴스에 여러개의 ENI를 연동 가능
            - 하나의 인스턴스가 한개 이상의 IP를 보유 가능
        - 인스턴스 유형 및 사이즈에 따라 최대 보유 가능한 IP주소가 변동
        - 내부적으로는 보안 그룹은 ENI에 부착
        - 기본적으로 Private IP주소와 Private 도메인 보유
            - 선택적으로 Public IP와 Public 도메인 보유
    - Elastic IP:
        - 도입 이유:
            - 인스턴스를 중지 후 재시작할 때, Public IP 변동
                
                ![image.png](image%2013.png)
                
                ![image.png](image%2014.png)
                
                ![image.png](image%2015.png)
                
        - EC2의 public IP를 고정해주는 서비스
            - 즉, 인스턴스를 중지 후 재시작해도 고정적인 IP를 확보 가능
                
                ![image.png](image%2016.png)
                
        - EC2이외에 다른 서비스 (ex: NLB)에도 사용
        - 내가 보유한 IP주소를 AWS에서 사용 가능
        - 리전 단위
        - 연결하지 않아도 보유하기만 해도 비용 발생 (IPv4비용 발생)
- EC2 유저 데이터:
    
    ![image.png](image%2017.png)
    
    - EC2 인스턴스의 최초 실행 시, 지정한 스크립트 실행 가능
        - 별도 설정을 통해서 재부팅마다 실행하도록 설정 가능
    - 두가지 모드:
        - Shell script
        - cloud-init: 리눅스 이미지의 부트스트래핑을 위한 오픈소스 어플리케이션
    - 주요 사용 사례:
        - EC2 인스턴스 설정 (보안 설정, 인스턴스 설정 등)
        - 외부 패키지 다운로드
        - 설치 어플리케이션 실행
        - 기타 EC2 실행 시, 필요한 동작
    - 인스턴스 메타데이터:
        - 실행 중인 인스턴스를 구성 또는 관리하는 데 사용될 수 있는 인스턴스 관련 데이터
        - 호스트 이름, 이벤트 및 보안 그룹과 같은 범주로 분류됨
        - EC2 인스턴스 메타데이터 (무료):
            - EC2 인스턴스의 속성 및 정보 데이터
                - AMI ID, IPv4/IPv6 주소, EBS 매핑, 보안 그룹 연동상황, IAM 역할 연동 등
            - 실행중인 EC2 인스턴스의 메타데이터 IMDS(Instance Metadata Service)로 조회 가능
                - HTTP endpoint 지원
                - IP주소: 169.254169.254(IPv4), fd00:ec2::254(IPv6)
                - 두가지 모드:
                    - IMDS v1: Request/Response 기반
                        - 별도의 보안 인증이 필요 없는 Request/Response 기반
                            - Link Local IP를 사용하기 때문에 해당 EC2 인스턴스에서만 요청 가능
                        - CloudWatch Metric을 활용해서 조회 횟수 기록 가능
                    - IMDS v2: 세션 기반(default)
                        - 보안 토큰을 발급받아 요청할 때마다 토큰을 사용해 인증하는 세션 방식
                            - 토큰의 유효기간은 1초에서 최대 6시간
                        - IMDSv1 보다 더 높은 보안 수준 제공
                            - IAM 정책 등을 활용하여 EC2 인스턴스가 IMDSv2를 사용하도록 강제 가능
                            - 활용 시, EC2 인스턴스 내부의 AWS CLI, SDK 등이 IMDSv2를 지원하는 최신 버전임을 확인 필요
            - 주용 사용 사례
                - 인스턴스 별 설정, IAM 임시 자격증명 조회 등(AWS CLI, SDK 등이 내부적으로 활용)
            - EC2 실행 시 메타데이터 액세스 가능 여부설정 가능
                - 기본 활성화
                - 버전 선택 가능
- EC2 권한 부여:
    
    ![image.png](image%2018.png)
    
    - IAM 자격 증명을 등록:
        
        ![image.png](image%2019.png)
        
        - IAM 사용자를 생성하고, IAM 자격증명을 발급 받아 EC2에 등록
        - AWS Confiugre를 통해 자격 증명을 파일로 등록 (~/.aws/credentials)
        - 관리가 어렵고 바꾸기 힘듦
    - IAM 역할을 부여
        
        ![image.png](image%2020.png)
        
        - 권한이 부여된 IAM 역할을 만들고 EC2에 부여
        - 관리가 쉽고 교체가 쉬움
        - 내부적으로 지속적으로 자격증명을 변경
            - 뛰어난 보안성
    - 자격증명 교체
        
        ![image.png](image%2021.png)
        
- EC2 Auto-scaling:
    - 어플리케이션을 모니터링하고 용량을 자동으로 조정하여, 최대한 저렴한 비용으로 안정적이고 예측 가능한 성능을 유지하게 함
    - Auto-scaling 기능을 활용하여 손쉽게 여러 서비스 전체에서 여러 리소스에 대한 어플리케이션 규모 조정을 설정할 수 있음
    - 정확한 수의 EC2 인스턴스를 보유하도록 보장
        - 그룹의 최소 인스턴스 숫자 및 초대 인스턴스 숫자
            - 최소 숫자 이하로 내려가지 않도록 인스턴스 숫자를 유지 (인스턴스 추가)
            - 최대 숫자 이상 늘어나지 않도록 인스턴스 숫자 유지 (인스턴스 삭제)
    - 다양한 스케일링 정책 적용
        - 다양한 스케일링 정책
            - 예시 1: CPU의 부하에 따라 인스턴스 크기를 늘리기
            - 예시 2: 특정 시간에 인스턴스 개수 늘리고, 다른 시간에 줄이기
        - AZ에 인스턴스가 골고루 분산될 수 있도록 인스턴스를 분배
        - 정책 종류:
            - 수동 스케일: 수동으로 직접 인스턴스 숫자를 증감
                - 주로 개발 환경 혹은 다른 정책을 적용하기 전 사전 테스트 용도로 사용
                - 되도록이면 다른 스케일 정책을 비활성화 시킨 후 적용 추천
            - 스케줄 기반 스케일: 특정 시점에 인스턴스 숫자를 증감
                
                ![image.png](image%2022.png)
                
                - 예측 가능한 시점의 변동사항에 대비해서 인스턴스 숫자를 조절하는 방식
                    - 예시: 매주 수요일마다 주간 이벤트가 있는 게임
                - 적용 방식
                    - 특정 시점을 정해서 해당 시점 or Cron으로 표현하는 반복 시점
                    - 범위 지정 (Min, Max, Desired 셋 중 최소 한가지 선택)
                        - 지정한 범위보다 인스턴스가 작다면 Scale-out, 크다면 Scale-in
                - Cron 표현 예시
                    
                    ![image.png](image%2023.png)
                    
                    ![image.png](image%2024.png)
                    
                    ![image.png](image%2025.png)
                    
                    ![image.png](image%2026.png)
                    
            - 동적 스케일: 특정 기준을 두고 기준치에 따라 인스턴스 숫자를 증감
                
                ![image.png](image%2027.png)
                
                - 지표에 반응해서 인스턴스 숫자를 조절하는 방식
                    - 주로 CloudWatch의 지표 활용
                    - 혹은 자신만의 기준으로 스케일링 정책 조절 가능
                - 주로  Auto-scale에서 지원하는 추적 조정 정책 (Target Tracking Policy) 활용
                    - 내부적으로 CloudWatch 경보(Alarm)을 생성해서 경보에 반응하여 자동으로 증감
                        - 경보: CloudWatch 지표에 반응하여 트리거되는 이벤트
                    - 지표 증감에 따라 얼마나 민감하게 반응할 것인지 결정 가능
                - 필요 시 커스텀 로직을 활용해서 Auto-scale의 증감을 수동으로 조절 가능
            - 예측 기반 스케일: 과거의 기록 패턴을 기반으로 수요량을 예측해서 인스턴스 숫자를 증감
                - 사용 패턴의 히스토리를 기반으로 인스턴스 수요량을 예측하여 인스턴스 숫자를 조절하는 방식
                    - 주로 반복되는 패턴이 명확한 경우, 혹은 인스턴스 준비가 오래 걸리는 경우 사용
                    - 예시: 매일 오후 2시에 이벤트가 열리는 게임 서비스의 서버
                - CloudWatch 지표를 14일간 분석하여 패턴을 만들고 다음 48시간의 사용 패턴을 분석
                - 수요량에 따라 증가만 가능
                    - 즉, 인스턴스 숫자를 감소시키려면 동적 스케일링 정책 필요
                - 주의사항
                    - Auto-scale Group에 다양한 인스턴스 종류가 섞여 있을 경우, 효율성이 매우 떨어짐
                    - 다양한 스케일링 정책이 공존할 경우, 효율성이 떨어짐
                    - Auto-scale Group에 충분한 데이터가 쌓일 때까지(2주) 기다림 필요
    - 시작 구성 (Launch configurations) / 시작 템플릿: 무엇을 실행시킬 것인가?
        
        ![image.png](image%2028.png)
        
        - EC2의 유형, 크기
        - AMI, 보안그룹, Key, IAM 역할
        - 유저 데이터 (EC2 실행 시 실행 할 자동 스크립트)
        - 기타 설정:
            - 종료 정책:
                - 기본:
                    - 인스턴스가 2개 이상인 AZ의 인스턴스에서
                    - 가장 오래된 시작 템플릿
                    - 모두 같은 시작 템플릿이라면 다음 과금 시간에 가장 가까운 인스턴스 종료
                - 커스텀:
                    - 가장 예전 시작 템플릿부터
                    - 가장 오래된 인스턴스부터
                    - 가장 최근 인스턴스부터 등
            - Lambda를 활용해서 커스텀 정책 적용 가능
    - 모니터링: 언제 실행시킬 것인가? + 상태 확인
        - 예시 1: CPU 점유율이 일정 %를 넘어섰을 때, 추가로 실행
        - 예시 2: 2개 이상이 필요한 스택에서 EC2 하나가 죽었을 때
        - CloudWatch (and/or) ELB와 연계
    - 설정: 얼마나 어떻게 실행시킬 것인가?
        - 최대/최소/원하는 인스턴스 숫자
        - ELB와 연동 등
- EC2 Elastic Load Balancer (ELB):
    
    ![image.png](image%2029.png)
    
    - 둘 이상의 AZ에서 EC2 인스턴스, 컨테이너, IP 주소 등 여러 대상에 걸쳐 수신되는 트래픽을 자동으로 분산함
    - 등록된 대상의 상태를 모니터링하면서, 상태가 양호한 대상으로만 트래픽을 라우팅함
    - ELB란?
        
        ![image.png](image%2030.png)
        
        - 다수의 EC2에 트래픽을 분산 시켜주는 서비스
        - 총 4가지 종류:
            - Application Load Balacner (ALB)
                - 똑똑한 녀석
                - OSI Model Layer 7
                - 트래픽을 모니터링하여 라우팅 가능
                    - 예시: [image.sample.com](http://image.sample.com) → 이미지 서버로, [web.sample.com](http://web.sample.com) → 웹 서버로 트래픽 분산
            - Network Load Balacner (NLB)
                - 빠른 녀석
                - OSI Model Layer 4
                - TCP, UDP 기반 빠른 트래픽 분산
                - Elastic IP 할당 가능 (IP 고정 가능)
            - Classic Load Balacner (CLB)
                - 옛날 녀석
                - 예전에 사용되던 타입으로 현재는 잘 사용하지 않음
            - Gateway Load Balacner (GLB)
                - 먼저 트래픽 체크하는 녀석
                - OSI Layer 3
                - 가상 어플라이언스 배포/확장 관리를 위한 서비스
        - Health 체크: 직접 트래픽을 발생시켜 인스턴스가 살아있는지 체크
        - Auto-scaling과 연동 가능
            - Auto-scaling을 통해 EC2 인스턴스 숫자를 관리하고, ELB를 통해 분산 트래픽 처리
            - Auto-scaling의 인스턴스 증감과 같이 ELB에 연결
        - 지속적으로 IP 주소가 바뀌며 IP 고정 불가능: 항상 도메인 기반으로 사용
    - 대상 그룹이란?
        
        ![image.png](image%2031.png)
        
        - ELB가 라우팅 할 대상의 집합
        - 구성:
            - 대상 종류: 인스턴스, IP, Lambda, ALB
            - 프로토콜: HTTP, HTTPS, gRPC, TCP 등
            - 기타설정: 트래픽 분산 알고리즘, 고정 세션 등
    - 리스너란?
        
        ![image.png](image%2032.png)
        
        - ALB로 들어오는 요청을 처리하는 주체
            - 들어오는 트래픽의 프로토콜 + 포트 단위
        - 규칙(Rule)으로 ALB에서 어떤 요청을 받을지, 요청을 어떻게 어디로 처리할지를 결정
            - 예시 1: HTTP 8080 포트로 트래픽을 받아서 A 대상그룹의 80번 포트로 배분
            - 예시 2: HTTPS 프로토콜 443 포트로 트래픽을 받아서 B 대상그룹의 80번 포트로 배분
            - 예시 3: HTTP POST 요청이 들어왔을 경우, 지정된 응답 전달 (에러페이지 등)
        - 규칙을 활용해 다양한 조건에 따라 트래픽 배분 가능
            - 활용 가능한 조건: Header, QueryString, source IP, Method 등
        - 들어오 트래픽 처리 방식: forward, redirect, fixed-response, cognito 인증 등
- EC2 Elastic File System (EFS):
    
    ![image.png](image%2033.png)
    
    - AWS 클라우드 서비스와 온프레미스 리소스에서 사용할 수 있는, 간단하고 확장 가능하며 탄력적인 완전관리형 NFS 파일 시스템을 제공함
    - 어플리케이션을 중단하지 않고, 온디맨드 방식으로 페타바이트 규모까지 확장하도록 구축되어, 파일을 추가하고 제거할 때 자동으로 확장하고 축소하며 확장 규모에 맞게 용량을 프로비저닝 및 관리할 필요가 없음
    - EFS란?
        
        ![image.png](image%2034.png)
        
        - NFS 기반 공유 스토리지 서비스 (NFSv4)
            - 따로 용량을 지정할 필요 없이 사용한 만큼 용량이 증가 ↔ EBS는 미리 크기를 지정해야함
        - 몇 천개의 동시 접속 유지 가능
        - 데이터는 여러 AZ에 나누어 분산 저장
        - 쓰기 후 읽기 (Read After Write) 일관성
        - Private Service: AWS 외부에서 접속 불가능
            - AWS 외부에서 접속하기 위해서는 VPN 혹은 Direct Connect 등으로 별도로  VPS와 연결 필요
        - 각 AZ에 Mount Target을 두고, 각각의 AZ에서 해당 Mount Target으로 접근
        - Linux Only
        - EFS 타입:
            - Regional: 리전 전체를 활용하여 고가용성과 내구성 확보
            - One-Zone: AZ 하나만 활용하여 고가용성과 내구성은 떨어지지만 저렴한 가격
        - EFS 퍼포먼스 모드:
            - 목적: 가장 보편적인 모드로써 거의 대부분의 경우 사용 권장
            - MAX I/O: 매우 높은 IOPS가 필요한 경우 (빅데이터, 미디어 처리 등)
        - EFT Throughput 모드:
            - Elastic Throughput (추천): EFS가 자동으로 throughput을 조절함 (예측하기 어렵거나, 적은 범위에서 변동이 있는 경우)
            - Bursting Throughput: 낮은 throughput일 때, 크레딧을 모아서 높은 throughput일 때 사용함 (EC2 T타입과 비슷한 개념)
            - Provisioned Throughput: 미리 지정한 만큼의 throughput을 미리 확보해두고 사용